ALTER TABLE familias
ADD COLUMN usar_imagen BOOLEAN DEFAULT false,
ADD COLUMN imagen_subtitulo TEXT;
